package com.sch.enums;

public enum Gender {
MALE,FEMALE,OTHERS
}
