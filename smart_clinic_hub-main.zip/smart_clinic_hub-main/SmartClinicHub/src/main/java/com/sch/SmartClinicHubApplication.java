package com.sch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartClinicHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartClinicHubApplication.class, args);
	}

}
