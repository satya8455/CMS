package com.sch.enums;

public enum Role {
	SUPER_ADMIN,
    ADMIN,
    DOCTOR,
    RECEPTIONIST
}
