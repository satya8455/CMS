package com.sch.enums;

public enum PaymentMode {
    CASH,
    CARD,
    UPI,
    PENDING
}
