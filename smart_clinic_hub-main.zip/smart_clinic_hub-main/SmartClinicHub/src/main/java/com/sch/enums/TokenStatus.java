package com.sch.enums;

public enum TokenStatus {
    WAITING,
    CALLED,
    SKIPPED,
    DONE
}
